module.exports = ({
    prefix: ".",
      money: "0",
      sob: "Z!sob para mudar:)",
      color: "#6ef800",
      gemas: "0",
      hex: "#6ef800",
      img: "https://media.discordapp.net/attachments/881238768915447841/881320764991754290/7ac630c5670ea447fba232982f2a268b.png",
      avatar: "https://media.discordapp.net/attachments/881238768915447841/881335232685555712/desconhecido.png"
    })