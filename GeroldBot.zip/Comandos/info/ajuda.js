module.exports = {
    name: "ajuda",
    aliases: ['help'],
    code: `
$title[Painel de Ajuda]
$thumbnail[https://cdn.discordapp.com/avatars/950421513222365214/663034f83d30f1a611eb2f088be0ec64.png?size=2048]
$description[

Economia:
\`daily\` \`work\` \`gemas\` \`carteira\`

Info:
\`botinfo\` \`ajuda/help\`

Entre no meu [Servidor](https://discord.gg/WkrvfAaGYv)
]
$color[$getServerVar[color]]`
}